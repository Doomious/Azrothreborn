# Azroth Reborn — Titan Walks World Blockout Specification

**Status:** Approved creative direction from project owner; **design specification, not implemented level geometry**.  
**Purpose:** Give Claude and any Unreal world-building collaborator a single reference for region identity, landmark composition, and Titan-oriented blockout.  
**Target repository:** `Doomious/Azrothreborn` (`main`); suggested path `Docs/Worldbuilding/TITAN_WALKS_WORLD_BLOCKOUT.md`.  
**Last authored:** 2026-10-30.

## 0. Core direction — read this first

The map is to be themed around **Titan Walks**: one spectacular, physically present, **BIPEDAL** meteor-born Titan per primary region. The Titans are *landscape-scale characters* and make each area's geography recognizable. Build the environment around the routes and landmarks of its Titan, not vice versa. They are not just stationary bosses or decorative statues.

**All 11 primary Titans:** exactly two locomotion legs, humanoid standing posture, two primary arms. Horns, shoulder trees, armor, vines, crystalline growth, etc. are allowed; quadrupedal or serpentine Titans are NOT the target. Scale suggestions below are exploratory art direction, not validated against Unreal navigation or gameplay.

Meteor origin: a celestial body struck the planet at **Starfall Crater**. Scattered fragments or resonance seeded the regions. Each biome gave its Titan different form, movement, ecology and powers. Titans can vary in disposition (neutral/protective/hostile); they are not all interchangeable fights. Every region offers a unique process of **claiming/capturing** its Titan. Whether claiming means summoning the giant, acquiring powers, gaining allegiance, or all three is **undecided**; do not implement this as a fixed game mechanic until decided.

## 1. What is verified versus proposed

### Verified from current repository source files

- Repository: `https://github.com/Doomious/Azrothreborn`.
- `/SourceArt/WorldMap/Output/WorldMap_Info.json`: world extent approximately **16.13 km × 10.58 km**, terrain elevation **-248 to +1,263 m**, **11 named zone IDs**, resolution 4033 × 2647.
- `/SourceArt/WorldMap/Tools/generate_world_maps.py`: generated zone-mask polygons, crater region geometry, biome classifications, and world map source pipeline.
- `/README.md`: `/Game/Maps/StarfallCrater_WP` World Partition map, streaming assets, and crater build workflow.
- The repository contains rendered world and crater references under `/SourceArt/WorldMap/Renders/` and `/SourceArt/Regions/StarfallCrater/v2/Renders/`.

### Confirmed design direction from owner (not necessarily reflected in current files)

- The world has a large central meteor crater and lake, with differing fantasy RPG biomes surrounding it.
- The primary visual/gameplay organization is **one bipedal Titan Walk for each region**.
- Earlier design changes requested replacing **Ashen Wastes** with a *Thousand Needles / Thunder Bluff-style stone-pillar landscape*, and **Hollow Blight Lands** with *dark swamplands*. These changes contradict the legacy zone names and classification still visible in the current generated data; **do not silently revert them**. Preserve the region slots/locations but reconcile biome labels, shaders, assets and Titan themes with the owner before bulk map regeneration.

**IMPORTANT:** The eleven names below map to the current repository's documented region IDs, not a claim that all terrain is already up to date. Treat affected legacy names as aliases until the newer blockout is synchronized.

## 2. World-scale staging rules for all Titan Walks

For each zone, block out:
1. **Hero sightline:** At least one strong view from the boundary or road where the Titan silhouette is visible against sky, mountains or water. Design the landmark/terrain so it reads at a distance.
2. **Titan route:** A wide, plausible loop or two-way route from landmark A through B to C and back, with a safe-sized movement corridor. Avoid going through tight settlements. Route is a design spline first, actual physics/nav behavior later.
3. **Rest pose:** A place where it periodically kneels, stands dormant or interacts with the ground; must read as part of the environment when Titan is absent.
4. **Environmental evidence:** Footprints, altered waterways, uprooted trees, broken spires, frost trails, charged crystals, etc. make the Titan tangible between sightings.
5. **Player affordances:** Observation/lookout points, cover, access paths, optional climbing or platforming surfaces, and a staged place for the region's unique claiming encounter.
6. **Ecology and civilization:** Settlements, roads, wildlife and ruins should respond to the Titan. The world's inhabitants have adapted to its presence.
7. **World Partition and optimization:** Maintain the repo's existing source/build pipeline; distant silhouettes can be represented by separate lightweight visual proxies / HLODs while close encounter bodies require the appropriate skeletal/animation setup. Do not assume 100–180 m skeletal meshes can use ordinary NPC AI, standard animation collision, or a simple navigation mesh without testing.

The listed heights are **concept ranges**. First measure biome footprints, path widths, skyline ratios, camera composition and performance. Then finalize each Titan's exact height. A tall visual centerpiece is not automatically a viable always-simulated actor across a 16-km map.

## 3. Proposed roster and region blockout directives

### 01 — Stormreach Isles | Thal'Kor, the Stormwalker | proposed 90 m
- **Form:** Broad bipedal humanoid formed from storm-black stone, marine crust and luminous water channels; two primary arms, barnacled shoulders, blue lightning veins.
- **Character:** Restless, territorial, indifferent to small travelers; neither simply evil nor a friendly pet.
- **Walk route:** Several island shallows and submerged stone shelves; at least two crossing points where its legs visibly break surf.
- **Hero landmarks:** Lightning-split sea arches; drowned stairway; a stormwatch lighthouse/ruin; tidal flats where the feet emerge.
- **Biome effects:** Storm clouds gather over its route; water churns; salt-sprayed rock and shell deposits mark old paths.
- **Claim encounter concept:** Ascend a sheltered leg/rock approach during a storm window to reach an exposed back or shoulder meteor shard.
- **Blockout priority:** Show walking in open water *without* requiring fully simulated ocean-wide hydrodynamics.

### 02 — Frostpeak Range | Vaelthir, the Glacier King | proposed 130 m
- **Form:** Two-legged giant with massive crystalline ice armor, granite frame, crown-like fractured ice crest.
- **Character:** Solitary, glacially slow, dangerous mostly by sheer mass.
- **Walk route:** Switchback through two mountain passes, frozen shelf, avalanche valley and high rest basin.
- **Hero landmarks:** Split glacier corridor; blue ice cathedral; high overlook; frozen riverbed where a Titan foot once stopped the current.
- **Biome effects:** Snowfall, frozen water, icefall, avalanche risk localized to dramatic traversal zones.
- **Claim encounter concept:** Break or melt successive shield plates to expose the star fragment, using terrain/thermal opportunities rather than ordinary DPS.
- **Blockout priority:** Ensure the colossal route does not cross steep slopes its foot placement cannot plausibly accommodate.

### 03 — Ashen Wastes (LEGACY NAME) / proposed Pillarlands revision | Mol'Gath, the Furnace Heart (PROVISIONAL)
- **Conflict:** Current world data defines a volcanic **Ashen Wastes**. Owner previously asked to turn it into a *Thousand Needles* landform of towering pillars. **Do not build a volcanic wasteland here without reconciling this.**
- **Initial Titan concept:** 105-m biped of obsidian armor with magma beneath, roaming lava channels; this suits the OLD volcanic version only.
- **Recommended revised candidate:** **Vorr'Khal, the Spirestrider** — 110-m bipedal titan with long balanced stone legs, layered sandstone torso, mesa-like shoulder fins and a meteor-bright sternum. Climbs among giant rock pillars; thunder echoes when it strikes a spire.
- **Walk route (new direction):** Circular corridor through tall stone needles, two connected plateau saddles, and a deep central ravine crossing.
- **Hero landmarks:** Needles skyline, pillar-top camp, ancient rope bridge, collapsed monolith, Titan resting alcove.
- **Biome effects:** Dust sheets, rockslides, fractured columns, migration paths cut between spires.
- **Claim encounter concept:** Manipulate pillar bridges/height to reach its sternum core during a brace or kneel.
- **Decision needed:** Confirm revised zone name, geography, and whether Mol'Gath moves to a future volcanic pocket or is retired.

### 04 — Sunscorch Desert | Sah'Ruun, the Dune Sovereign | proposed 115 m
- **Form:** Tall regal biped, monumental sandstone and bronze/gold inlays, sweeping shoulder fins and narrow face mask.
- **Character:** Ritualistic and mysterious; occasionally stops for days like a monument.
- **Walk route:** Ancient caravan corridor, crescent dunes, buried city edge, rocky escarpment.
- **Hero landmarks:** Half-buried colossal gateway; oasis; sandstone observatory; settlement placed outside destructive route.
- **Biome effects:** Sand veils, shifting dunes, temporary revealed ruins and tracks.
- **Claim encounter concept:** Follow changing signs in a sandstorm, uncover access around its legs, and solve a celestial-seal approach.
- **Blockout priority:** Its monument-like dormancy should make players second-guess whether that distant silhouette is a building.

### 05 — Emberwood Forest | Oru'Moss, the Elderwood Titan | proposed 145 m
- **Form:** Thick two-legged humanoid of old-growth wood and dark stone, huge root feet, two branch-covered arms, layered tree canopy over shoulders.
- **Character:** Ancient, protective, largely peaceful.
- **Walk route:** Three large ancient-forest clearings connected by a wide canopy gap / old migration passage.
- **Hero landmarks:** Giant footprint pool; tree bridge; old sacred grove; settlement hidden along an off-route ridge.
- **Biome effects:** New vegetation in footprints, branchfall, startled herds, bird colonies on the body.
- **Claim encounter concept:** Root-and-branch ascent at a resting grove, favoring patience and understanding over killing.
- **Blockout priority:** This is the iconic **forest** biped, but distinguish it strongly from the crater's cosmic woodland Titan.

### 06 — Stonevale Highlands | Khar'Voss, the Pillarbreaker | proposed 100 m
- **Form:** Broad biped of layered gray granite, squat muscular legs, angular slab shoulders, two heavy arms.
- **Character:** Stubborn, territorial, sculptor-like.
- **Walk route:** High grass-and-stone plateau; boulder fields; terrace edge; sheltered quarry-like basin.
- **Hero landmarks:** Uplifted circular amphitheater, rockfall gorge, Titan-carved standing stones, hilltop watchtower.
- **Biome effects:** Tumbled boulders, stacked cairns, newly split cliffs and rock dust.
- **Claim encounter concept:** Reveal a chest core by using stone counterweights, breakable shields and vertical landscape access.
- **Blockout priority:** If Ashen Wastes becomes pillarlands, **differentiate this zone**: rolling highland plateaus and granite massifs here; exaggerated needle spires in the revised northern/eastern pillar region.

### 07 — Ember Coast | Ael'Marin, the Tidebound | proposed 85 m
- **Form:** Elegant two-legged coastal humanoid of pale limestone, translucent turquoise striations, shell and sea-glass details.
- **Character:** Wanderer and protector of coastal creatures.
- **Walk route:** Shoreline shelf at low tide, tidal flats, sea-cliff approach and washed-out ruins.
- **Hero landmarks:** Tidal amphitheater, stranded ship hull, cave exposed at ebb tide, sea cliffs with lookouts.
- **Biome effects:** Rolling spray, revealed tidal pools, wet reflective footprints and displaced driftwood.
- **Claim encounter concept:** Timing-based exploration via tide states to access the meteor heart.
- **Blockout priority:** Distinguish from Stormreach: blue sunny coast, not constant thunderstorms.

### 08 — Mosswarden Swamps | Mor'Vael, the Bogfather | proposed 110 m
- **Form:** Bipedal giant of mangrove roots, dark peat, waterlogged wood and glowing amber eyes; two great arms and long stiltlike legs.
- **Character:** Unsettling but not inherently malevolent, extremely patient.
- **Walk route:** Deep flooded basin, mangrove corridor and raised mud island; sometimes rests half-submerged.
- **Hero landmarks:** Sunken shrine, reed field, collapsed causeway, giant hollow tree.
- **Biome effects:** Blackwater pools, gas bubbles, thick mist, awakened insects, shifting root bridges.
- **Claim encounter concept:** Manipulate sluice gates or drainage to uncover its lower body, then traverse exposed root structures.
- **Blockout priority:** Make its half-submerged posture silhouette readable from a swamp lookout.

### 09 — Hollow Blight Lands (LEGACY NAME) / proposed Dark Swamplands revision | Xal'Veth, the Hollow King (PROVISIONAL)
- **Conflict:** Repo names this a blighted purple/crystal biome; owner requested **dark swamp** replacing it. This region should not quietly revert to crystal blight.
- **Initial concept:** 125-m skeletal biped held by purple star-crystals, emitting a blight field — suitable only if deliberate crystal remnants are kept.
- **Recommended revised candidate:** **Nhal'Veth, the Drowned Hollow** — 125-m terrifying two-legged hollow-trunk titan, skeletal driftwood limbs, swamp-water chest cavity holding the meteor core, pale will-o'-wisp lights, no obligatory purple corruption.
- **Walk route (new direction):** Black flooded forest, drowned town edges, dead willow island and an old elevated causeway.
- **Hero landmarks:** Drowned bell tower, dark root maze, sinking cemetery, blackwater mirror-lake.
- **Biome effects:** Moving dark water, hanging fog, drowned vegetation, disorienting light phenomena.
- **Claim encounter concept:** Locate the true core by investigating reflections/ghost lights, enter the hollow chest when it kneels.
- **Blockout priority:** Distinguish from Mosswarden: this is **dead/haunted/dark swamp**, while Mosswarden is **living mangrove wetland**.
- **Decision needed:** Finalize the new regional name and whether any old blight crystals remain as ruins or are removed entirely.

### 10 — Verdant Isles | Elarion, the Verdant Guardian | proposed 95 m
- **Form:** Upright biped with polished green stone armor, flowering tropical vines, warm golden celestial glyphs, two long arms.
- **Character:** Guardian, reverent and selective about whom it accepts.
- **Walk route:** Island forest ridge, ancient causeway, sacred shore and high temple terrace.
- **Hero landmarks:** Temple grove, tree-covered arch, open scenic overlook, sheltered village separated from the patrol.
- **Biome effects:** Blossoms, bird migrations and unusually vibrant foliage follow the route.
- **Claim encounter concept:** Environmental restoration or trust trials, **not** a routine kill.
- **Blockout priority:** Lean tropical and ceremonial, not a repeat of Emberwood's colossal treant.

### 11 — Starfall Crater Rainforest | Azh'Roth, the Firstborn | proposed 180 m
- **Form:** Tall bipedal primordial humanoid, dark petrified wood, cosmic violet-blue meteor crystal, vast branching back/shoulder crown, exposed star fragment in chest.
- **Character:** Oldest/closest link to impact origin, powerful, potentially mysterious rather than aggressive.
- **Walk route:** Crater-lake rim, deep jungle canopy break, waterfall edge, lake entry and ritual resting shelf; keep lake/clearing sightline central.
- **Hero landmarks:** Impact lake, crater rim overlook, central celestial spire, ancient ruins, waterfall terraces, Titan's lake-entry shore.
- **Biome effects:** Subtle waves when it enters water, canopy movement, starlit fog, strange pulse of growth around resting sites.
- **Claim encounter concept:** Requires understanding/aligning the fragments or rites gathered from prior regions; the exact gate is provisional, not established progression canon.
- **Blockout priority:** This Titan must visually connect **every** zone. Give it the clearest unique celestial element and avoid presenting the crater lake as a physically trivial puddle beside a 180-m creature.

## 4. Suggested region workflow for Claude / Unreal collaborator

**Do not replace the current landscape wholesale.** Respect existing content, region IDs, LFS-locked `.uasset`/`.umap` files, the World Partition level and the third-party Fab dependencies listed in README.

### Pass A — Audit, no destructive changes
- Open `SourceArt/WorldMap/Output/WorldMap_Info.json`, `SourceArt/WorldMap/Output/Zones_Preview.png`, `SourceArt/WorldMap/WorldMap_Concept.png`, `SourceArt/WorldMap/Tools/generate_world_maps.py`, `/README.md` and relevant render references.
- Verify whether newer local map edits exist outside the checked-in branch; especially **Ashen Wastes → pillarlands** and **Hollow Blight Lands → dark swamp**.
- Capture region bounds and actual clearances. Report discrepancies before changing terrain or zone IDs.

### Pass B — Titan Walk blockout for each zone
- Create named **route splines**, **lookout markers**, **rest-area markers**, **claim-encounter markers**, and footprint/impact decal locations in a separate non-destructive design layer or source data format.
- Use simple humanoid stand-ins, **not** final animated Titan assets.
- Mark crossings and collision hazards; use a distant proxy when the Titan is outside active gameplay range.
- Preserve a clear skyline framing the creature and a local approach where the player can feel scale.

### Pass C — Vertical slice and tech proof
- Build/test a single Titan Walk in a representative region, preferably Emberwood or Starfall Crater, before scattering final giants across 11 zones.
- Verify spline traversal, giant foot placement, obstacle clearance, proxy swaps, streaming boundaries, footstep VFX, camera scale, frame rate and client gameplay behavior.
- Measure then set working Titan dimensions and performance budgets based on actual results.

### Pass D — Expand to other zones
- Reuse the route marker schema, walk framework and streaming rules; personalize VFX, animations, resting poses, landmarks and claim encounters per region.
- Do not freeze final biome shaders for the two pending region revisions until resolved.

## 5. Definition of done for **each region's blockout**

- [ ] Region identity and naming reconciled with owner direction.
- [ ] Distinct bipedal Titan concept and readable silhouette set.
- [ ] Walking route, turns, rest pose and minimum clearance annotated.
- [ ] Three or more strong terrain/environment landmarks that reinforce that Titan.
- [ ] At least one far skyline view and one close observation/encounter position.
- [ ] Environmental reactions/footprint locations specified.
- [ ] Unique capture/claim encounter *design* location staged (actual mechanics can remain undecided).
- [ ] No unnecessary destruction of existing project world assets.
- [ ] World Partition/visual proxy test and performance results documented when implemented.

## 6. Open decisions — explicitly do NOT invent these as settled

1. **Capture outcome:** Follow/summon the giant? Bestow Titan powers? Allegiance and world patrol remain? A hybrid?
2. **Legacy geography:** Final names and biome palettes for revised Ashen Wastes and Hollow Blight Lands; whether any volcano/blight pockets survive elsewhere.
3. **Titan sizes:** Relative heights above are art-direction targets, subject to actual path/build/performance tests.
4. **Narrative order:** Are all Titans required, or can players claim them in any order? Is Firstborn the finale?
5. **Persistence:** Can Titans roam unattended across World Partition boundaries, and how are they represented when no player is nearby?

## 7. Implementation status and handoff

This document is a **design and blockout specification only**. It does not claim Titans, animations, patrol routes, quests, claim mechanics or modified geography have been implemented. Source links and metadata were inspected in repository; binary map assets and Unreal editor behavior were **not** fully verified. Claude should implement incrementally, record actual changes with paths/commits and report tested vs pending work.
